Project 4

**************************
Kenneth Shi
304063313

Jia Dan Duan
604022222
**************************


References:
- http://stackoverflow.com/questions/5503900/how-to-sort-an-array-of-objects-with-jquery-or-javascript (custom sort function for our Bids)
- http://stackoverflow.com/questions/2163045/how-to-remove-line-breaks-from-a-file-in-java (Line break replacement)
- http://api.jquery.com/jquery.parsexml/ (Parsing XML using jQuery)

Design Decisions:

In Part A, the decision in setting up the ItemServlet was to pass in the entire XML file, and then use jQuery/Javascript to parse the XML for display on the item.jsp file. This was mainly because I wanted to learn jQuery and thought this was a good oppurtunity to do so. 

In Part B, we followed the tutorial that was posted on the website, and then used the xmlhttprequest functionality to get our suggestions to work.
