DROP TABLE spatial_item;
