ALL README COMMENTS ARE IN project3-indexer


